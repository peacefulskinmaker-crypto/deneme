import { createClient } from "contentful"

const client = createClient({
  space: "qc3j459ks9ph",
  accessToken: "QIrfSvOnl73OjoRlM3tbOt3RgzSrHiRPyG4ocXu7oXs",
})

export interface ContentfulEntry {
  sys: {
    id: string
    contentType: {
      sys: {
        id: string
      }
    }
  }
  fields: Record<string, any>
}

export async function getAllEntries(): Promise<ContentfulEntry[]> {
  try {
    console.log("[v0] Fetching all entries from Contentful...")
    const response = await client.getEntries({
      limit: 100, // Get up to 100 entries
    })

    console.log("[v0] Successfully fetched entries:", response.items.length)
    console.log("[v0] Available content types:", [
      ...new Set(response.items.map((item) => item.sys.contentType.sys.id)),
    ])

    response.items.forEach((item, index) => {
      console.log(`[v0] Entry ${index + 1}:`, {
        id: item.sys.id,
        contentType: item.sys.contentType.sys.id,
        fields: Object.keys(item.fields),
      })
    })

    return response.items as ContentfulEntry[]
  } catch (error) {
    console.error("[v0] Error fetching all entries:", error)
    return []
  }
}

export async function getEvents(): Promise<ContentfulEntry[]> {
  try {
    console.log("[v0] Getting events...")
    const allEntries = await getAllEntries()

    // Filter for entries with contentType 'event' or similar
    const eventEntries = allEntries.filter((entry: ContentfulEntry) => {
      const contentType = entry.sys.contentType.sys.id.toLowerCase()
      return contentType.includes("event") || contentType.includes("etkinlik")
    })

    console.log("[v0] Found event entries:", eventEntries.length)
    return eventEntries
  } catch (error) {
    console.error("[v0] Error in getEvents:", error)
    return []
  }
}

export async function getContentEntries(): Promise<ContentfulEntry[]> {
  try {
    console.log("[v0] Getting content entries...")
    const allEntries = await getAllEntries()

    // Filter for entries that are NOT events
    const contentEntries = allEntries.filter((entry: ContentfulEntry) => {
      const contentType = entry.sys.contentType.sys.id.toLowerCase()
      return !contentType.includes("event") && !contentType.includes("etkinlik")
    })

    console.log("[v0] Found content entries:", contentEntries.length)
    return contentEntries
  } catch (error) {
    console.error("[v0] Error in getContentEntries:", error)
    return []
  }
}

export async function getHeroContent(): Promise<ContentfulEntry | null> {
  try {
    console.log("[v0] Getting hero content...")
    const allEntries = await getAllEntries()

    if (allEntries.length > 0) {
      console.log("[v0] Using first entry as hero content:", allEntries[0].sys.contentType.sys.id)
      return allEntries[0]
    }

    console.log("[v0] No entries found for hero content")
    return null
  } catch (error) {
    console.error("[v0] Error in getHeroContent:", error)
    return null
  }
}

export async function getCarouselContent(): Promise<ContentfulEntry[]> {
  try {
    console.log("[v0] Getting carousel-specific content...")
    const allEntries = await getAllEntries()

    // Filter for entries that are specifically for carousel (not events)
    const carouselEntries = allEntries.filter((entry: ContentfulEntry) => {
      const contentType = entry.sys.contentType.sys.id.toLowerCase()
      // Exclude events and only include entries with images
      const isNotEvent = !contentType.includes("event") && !contentType.includes("etkinlik")
      const hasImage = entry.fields && (entry.fields.image || entry.fields.photo || entry.fields.picture)

      return isNotEvent && hasImage
    })

    console.log("[v0] Found carousel entries:", carouselEntries.length)
    return carouselEntries
  } catch (error) {
    console.error("[v0] Error in getCarouselContent:", error)
    return []
  }
}
