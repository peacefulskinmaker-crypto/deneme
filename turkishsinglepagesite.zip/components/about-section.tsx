export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-primary">About Us</h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-12 text-pretty">
            ULSA Motorsport Kulübü, üniversite bünyesinde motor sporları ve alternatif sürüş disiplinlerine ilgi duyan
            öğrencileri bir araya getirerek, hem sportif hem de sosyal anlamda dinamik bir topluluk oluşturmayı
            hedefler. Kulübümüzün temel amacı, öğrencilerin farklı sürüş deneyimlerini yaşayabilecekleri, kendilerini
            geliştirebilecekleri ve aynı zamanda keyifli vakit geçirebilecekleri bir ortam yaratmaktır. Bu site
            öğrenciler tarafından açılmış, öğrenciler tarafından yürütülen ve yine öğrencileri etkinliklerden haberdar
            etmek adına açılmıştır.
          </p>

          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="text-center slide-up">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Motorsport Experience</h3>
              <p className="text-muted-foreground">
                Motor sporları ve alternatif sürüş deneyimleri ile adrenalin dolu anlar yaşayın.
              </p>
            </div>

            <div className="text-center slide-up">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-black" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82zM12 3L1 9l11 6 9-4.91V17h2V9L12 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Student Community</h3>
              <p className="text-muted-foreground">
                Üniversite öğrencileri tarafından yürütülen dinamik ve sosyal bir topluluk.
              </p>
            </div>

            <div className="text-center slide-up">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M16 4c0-1.11.89-2 2-2s2 .89 2 2-.89 2-2 2-2-.89-2-2zm4 18v-6h2.5l-2.54-7.63A1.5 1.5 0 0 0 18.54 8H16c-.8 0-1.54.37-2 1l-3 4v2h2l2.54-3.4L16.5 18H20z" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold mb-3">Social Events</h3>
              <p className="text-muted-foreground">
                Etkinlikler ve organizasyonlar ile öğrenci hayatınızı renklendirin.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
