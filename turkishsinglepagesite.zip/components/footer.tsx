import Image from "next/image"

export function Footer() {
  return (
    <footer id="contact" className="bg-[#1E1E1E] text-[#F5F5F5] py-16">
      <div className="container mx-auto px-4">
        <div className="flex justify-center">
          <div className="max-w-4xl w-full">
            <div className="grid md:grid-cols-3 gap-12 mb-8">
              <div className="text-center">
                <h3 className="text-3xl font-bold mb-4 text-primary">WILD Extreme Motorsports Club</h3>
                <p className="text-[#F5F5F5]/80 leading-relaxed text-lg">
                  Sadece hız ve yarış heyecanını değil; aynı zamanda topluluk ruhunu, öğrenme arzusunu ve sporun
                  birleştirici gücünü ön plana çıkarmayı misyon edindik.
                </p>
              </div>

              <div className="text-center">
                <h4 className="text-xl font-semibold text-accent mb-4">İletişim</h4>
                <div className="flex items-center justify-center gap-3 mb-4">
                  <a
                    href="https://facebrowser-tr.gta.world/pages/wild"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="transition-transform duration-300 hover:scale-110"
                  >
                    <Image
                      src="/facebrowser-logo.png"
                      alt="Facebrowser"
                      width={20}
                      height={20}
                      className="w-5 h-5 hover:opacity-80 transition-opacity duration-300"
                    />
                  </a>
                  <a
                    href="https://discord.gg/zAbTfJYTf8"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="transition-transform duration-300 hover:scale-110"
                  >
                    <Image
                      src="/discord-logo-new.png"
                      alt="Discord"
                      width={20}
                      height={20}
                      className="w-5 h-5 hover:opacity-80 transition-opacity duration-300"
                    />
                  </a>
                </div>
                <div className="space-y-2 text-[#F5F5F5]/80 text-lg">
                  <p>📞 9782340</p>
                  <p>📧 info@motorsport.ulsa</p>
                  <p>📍 Los Santos, USA</p>
                </div>
              </div>

              <div className="text-center">
                <h4 className="text-xl font-semibold mb-4 text-accent">Sporlar</h4>
                <ul className="space-y-2 text-[#F5F5F5]/80 text-lg">
                  <li>Rally Racing</li>
                  <li>Drift Racing</li>
                  <li>Motocross</li>
                  <li>ATV Racing</li>
                  <li>Supercross</li>
                  <li>Monster Truck</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <div className="max-w-4xl w-full border-t border-accent/20 pt-8 text-center">
            <p className="text-[#F5F5F5]/60 text-lg">© 2025 WILD Extreme Motorsports Club. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
