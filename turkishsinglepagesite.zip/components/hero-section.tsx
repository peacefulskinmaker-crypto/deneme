"use client"

import { useEffect, useState } from "react"
import { getHeroContent, type ContentfulEntry } from "@/lib/contentful"

export function HeroSection() {
  const [heroContent, setHeroContent] = useState<ContentfulEntry | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchHeroContent() {
      const content = await getHeroContent()
      setHeroContent(content)
      setLoading(false)
    }
    fetchHeroContent()
  }, [])

  const defaultContent = {
    title: "Unutulmaz Anılar",
    subtitle: "Yaratıyoruz",
    description: "Her etkinliği özel kılan detaylarla, hayallerinizdeki organizasyonu gerçeğe dönüştürüyoruz.",
    backgroundImage: "/modern-event-venue-with-elegant-lighting.jpg",
  }

  const getFieldValue = (fieldName: string, fallback: string) => {
    if (!heroContent?.fields) return fallback

    // Try exact match first
    if (heroContent.fields[fieldName]) return heroContent.fields[fieldName]

    // Try case-insensitive match
    const key = Object.keys(heroContent.fields).find((k) => k.toLowerCase() === fieldName.toLowerCase())
    return key ? heroContent.fields[key] : fallback
  }

  const content = {
    title: getFieldValue("title", defaultContent.title),
    subtitle: getFieldValue("subtitle", defaultContent.subtitle),
    description: getFieldValue("description", defaultContent.description),
  }

  const getBackgroundImage = () => {
    if (!heroContent?.fields) return defaultContent.backgroundImage

    // Look for common image field names
    const imageFields = ["backgroundImage", "image", "heroImage", "banner"]
    for (const fieldName of imageFields) {
      const field =
        heroContent.fields[fieldName] ||
        heroContent.fields[
          Object.keys(heroContent.fields).find((k) => k.toLowerCase().includes(fieldName.toLowerCase())) || ""
        ]

      if (field?.fields?.file?.url) {
        return field.fields.file.url.startsWith("http") ? field.fields.file.url : `https:${field.fields.file.url}`
      }
    }
    return defaultContent.backgroundImage
  }

  const backgroundImage = getBackgroundImage()

  if (loading) {
    return (
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 animate-pulse">
          <div className="absolute inset-0 bg-black/40" />
        </div>
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <div className="h-20 bg-white/20 rounded-lg mb-6 animate-pulse"></div>
          <div className="h-6 bg-white/20 rounded-lg mb-8 animate-pulse"></div>
        </div>
      </section>
    )
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div
        className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20"
        style={{
          backgroundImage: `url('${backgroundImage}')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 font-[family-name:var(--font-playfair)] text-balance">
          {content.title}
          <span className="block text-secondary">{content.subtitle}</span>
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-gray-200 leading-relaxed text-pretty">{content.description}</p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => document.getElementById("events")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
          >
            Etkinlikleri Keşfet
          </button>
          <button
            onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
            className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-4 rounded-lg text-lg font-semibold transition-colors"
          >
            Hakkımızda
          </button>
        </div>
      </div>
    </section>
  )
}
