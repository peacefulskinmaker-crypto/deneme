"use client"

import { useState, useEffect, useRef } from "react"
import { getCarouselContent } from "@/lib/contentful"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface CarouselItem {
  url: string
  alt: string
}

export function PhotoCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [carouselImages, setCarouselImages] = useState<CarouselItem[]>([])
  const [loading, setLoading] = useState(true)
  const [progress, setProgress] = useState(0)
  const [isHovered, setIsHovered] = useState(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const progressIntervalRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    const fetchCarouselContent = async () => {
      try {
        console.log("[v0] Fetching carousel content from Contentful...")
        const entries = await getCarouselContent()
        console.log("[v0] Carousel entries:", entries)

        const uniqueImages = new Map()
        const images = entries
          .map((entry: any) => {
            const imageField = entry.fields.image || entry.fields.photo || entry.fields.picture
            const imageUrl = imageField?.fields?.file?.url || imageField?.sys?.id
            const title = entry.fields.title || entry.fields.name || "Carousel Image"
            const entryId = entry.sys.id

            return {
              id: entryId,
              url: imageUrl ? `https:${imageUrl}` : "/vibrant-indoor-event.png",
              alt: title,
            }
          })
          .filter((image: any) => {
            // Remove duplicates based on URL
            if (uniqueImages.has(image.url)) {
              return false
            }
            uniqueImages.set(image.url, true)
            return true
          })
          .map(({ id, url, alt }: any) => ({ url, alt }))

        if (images.length > 0) {
          setCarouselImages(images)
        } else {
          setCarouselImages([
            {
              url: "/elegant-event-photo.jpg",
              alt: "Event Photo 1",
            },
            {
              url: "/corporate-event-photo.jpg",
              alt: "Event Photo 2",
            },
            {
              url: "/celebration-photo.jpg",
              alt: "Event Photo 3",
            },
          ])
        }
      } catch (error) {
        console.error("[v0] Error fetching carousel content:", error)
        setCarouselImages([
          {
            url: "/elegant-event-photo.jpg",
            alt: "Event Photo 1",
          },
          {
            url: "/corporate-event-photo.jpg",
            alt: "Event Photo 2",
          },
        ])
      } finally {
        setLoading(false)
      }
    }

    fetchCarouselContent()
  }, [])

  const startIntervals = () => {
    // Clear existing intervals
    if (intervalRef.current) clearInterval(intervalRef.current)
    if (progressIntervalRef.current) clearInterval(progressIntervalRef.current)

    // Reset progress
    setProgress(0)

    // Start progress interval
    progressIntervalRef.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          return 100
        }
        return prev + 0.1
      })
    }, 10)

    // Start slide change interval
    intervalRef.current = setInterval(() => {
      setCurrentIndex((prevIndex) => {
        const nextIndex = prevIndex + 1
        return nextIndex >= carouselImages.length ? 0 : nextIndex
      })
      setProgress(0) // Reset progress when changing slides
    }, 10000)
  }

  useEffect(() => {
    if (carouselImages.length === 0) return

    startIntervals()

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current)
    }
  }, [carouselImages.length])

  const goToPrevious = () => {
    setCurrentIndex((prevIndex) => {
      const newIndex = prevIndex - 1
      return newIndex < 0 ? carouselImages.length - 1 : newIndex
    })
    startIntervals()
  }

  const goToNext = () => {
    setCurrentIndex((prevIndex) => {
      const nextIndex = prevIndex + 1
      return nextIndex >= carouselImages.length ? 0 : nextIndex
    })
    startIntervals()
  }

  if (loading) {
    return (
      <section className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="text-gray-500 text-xl">Yükleniyor...</div>
      </section>
    )
  }

  return (
    <section id="home" className="min-h-screen relative overflow-hidden">
      <div
        className="relative h-screen"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {carouselImages.map((image, index) => (
          <div
            key={`${image.url}-${index}`}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={image.url || "/placeholder.svg"}
              alt={image.alt}
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-black/20" />
          </div>
        ))}

        {isHovered && (
          <>
            <button
              onClick={goToPrevious}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 p-2 transition-all duration-200 z-10"
            >
              <ChevronLeft className="w-8 h-8 text-white/80 hover:text-white drop-shadow-lg" />
            </button>
            <button
              onClick={goToNext}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 p-2 transition-all duration-200 z-10"
            >
              <ChevronRight className="w-8 h-8 text-white/80 hover:text-white drop-shadow-lg" />
            </button>
          </>
        )}

        <div className="absolute bottom-5 left-8 right-8">
          {/* Progress road */}
          <div className="relative h-1 bg-white/30 rounded-full overflow-hidden backdrop-blur-sm shadow-lg">
            <div
              className="absolute left-0 top-0 h-full bg-white/70 rounded-full transition-all duration-75 ease-linear"
              style={{ width: `${progress}%` }}
            />
          </div>

          <div
            className="absolute -top-6 transition-all duration-75 ease-linear transform -translate-x-1/2"
            style={{ left: `${progress}%` }}
          >
            <img
              src="/progress-motorcycle.png"
              alt="Motorcycle progress indicator"
              className="w-8 h-8 drop-shadow-lg filter brightness-0 invert opacity-90 transform hover:scale-110 transition-transform duration-200"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
