"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getEvents, type ContentfulEntry } from "@/lib/contentful"

export function EventsSection() {
  const [expandedEvent, setExpandedEvent] = useState<string | null>(null)
  const [events, setEvents] = useState<ContentfulEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [isAnimating, setIsAnimating] = useState(false)

  const fetchEvents = async () => {
    setLoading(true)
    const contentfulEvents = await getEvents()
    setEvents(contentfulEvents)
    setLoading(false)
  }

  useEffect(() => {
    fetchEvents()
  }, [])

  const toggleEvent = (eventId: string) => {
    if (expandedEvent === eventId) {
      setIsAnimating(false)
      setTimeout(() => {
        setExpandedEvent(null)
      }, 1000)
    } else {
      setExpandedEvent(eventId)
      setTimeout(() => {
        setIsAnimating(true)
      }, 50)
    }
  }

  const getEventField = (event: ContentfulEntry, fieldName: string, fallback = "") => {
    if (!event.fields) return fallback

    if (event.fields[fieldName]) return event.fields[fieldName]

    const key = Object.keys(event.fields).find(
      (k) => k.toLowerCase() === fieldName.toLowerCase() || k.toLowerCase().includes(fieldName.toLowerCase()),
    )
    return key ? event.fields[key] : fallback
  }

  const getEventImage = (event: ContentfulEntry) => {
    if (!event.fields) return "/placeholder.svg"

    const imageFields = ["image", "photo", "picture", "thumbnail"]
    for (const fieldName of imageFields) {
      const field =
        event.fields[fieldName] ||
        event.fields[Object.keys(event.fields).find((k) => k.toLowerCase().includes(fieldName.toLowerCase())) || ""]

      if (field?.fields?.file?.url) {
        return field.fields.file.url.startsWith("http") ? field.fields.file.url : `https:${field.fields.file.url}`
      }
    }
    return "/placeholder.svg"
  }

  if (loading) {
    return (
      <section id="events" className="py-20 bg-secondary">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-6xl md:text-7xl font-bold mb-8 text-primary">Our Events</h2>
            <p className="text-2xl text-secondary-foreground max-w-2xl mx-auto text-pretty">
              Motor sporları ve sosyal etkinliklerimizle üniversite hayatınızı renklendiriyoruz
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardContent className="p-0">
                  <div className="w-full h-48 bg-muted rounded-t-lg"></div>
                  <div className="p-6">
                    <div className="h-6 bg-muted rounded mb-2"></div>
                    <div className="h-4 bg-muted rounded"></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    )
  }

  if (events.length === 0) {
    return (
      <section id="events" className="py-20 bg-primary">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-6xl md:text-7xl font-bold mb-8 text-primary-foreground">Our Events</h2>
            <p className="text-2xl text-primary-foreground/90 max-w-2xl mx-auto text-pretty mb-8">
              Motor sporları ve sosyal etkinliklerimizle üniversite hayatınızı renklendiriyoruz
            </p>
            <Button
              onClick={fetchEvents}
              className="bg-[#1E1E1E] text-[#F5F5F5] hover:bg-[#1E1E1E]/90 font-semibold px-8 py-3 transition-all duration-200 hover:scale-105 text-xl"
            >
              Refresh Events
            </Button>
          </div>

          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 bg-primary-foreground/20 rounded-full flex items-center justify-center">
              <svg className="w-12 h-12 text-primary-foreground" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
              </svg>
            </div>
            <h3 className="text-4xl font-semibold text-primary-foreground mb-4">No Events Yet</h3>
            <p className="text-2xl text-primary-foreground/90 mb-8 max-w-md mx-auto">
              Henüz etkinlik eklenmemiş. Yeni etkinlikler için sayfayı yenileyin.
            </p>
          </div>
        </div>
      </section>
    )
  }

  return (
    <>
      <section id="events" className="py-20 bg-primary relative">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-6xl md:text-7xl font-bold mb-8 text-primary-foreground">Our Events</h2>
            <p className="text-2xl text-primary-foreground/90 max-w-2xl mx-auto text-pretty mb-8">
              Motor sporları ve sosyal etkinliklerimizle üniversite hayatınızı renklendiriyoruz
            </p>
            <Button
              onClick={fetchEvents}
              className="bg-[#1E1E1E] text-[#F5F5F5] hover:bg-[#1E1E1E]/90 font-semibold px-8 py-3 transition-all duration-200 hover:scale-105 text-xl"
            >
              Refresh Events
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {events.map((event) => {
              const imageUrl = getEventImage(event)
              const title = getEventField(event, "title", "Etkinlik")
              const shortDescription = getEventField(event, "shortDescription", "Açıklama mevcut değil")

              return (
                <Card
                  key={event.sys.id}
                  className="cursor-pointer hover:shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-accent/20 bg-card border-accent/20 overflow-hidden"
                  onClick={() => toggleEvent(event.sys.id)}
                >
                  <div className="relative">
                    <img src={imageUrl || "/placeholder.svg"} alt={title} className="w-full h-48 object-cover" />
                    <div className="p-6">
                      <h3 className="text-2xl font-semibold mb-2 text-foreground">{title}</h3>
                      <p className="text-muted-foreground text-lg">{shortDescription}</p>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {expandedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-all duration-1000 ease-out ${
              isAnimating ? "opacity-100" : "opacity-0"
            }`}
            onClick={() => toggleEvent(expandedEvent)}
          />

          <div
            className={`relative z-10 w-full max-w-4xl transform transition-all duration-1000 ease-out ${
              isAnimating ? "scale-100 opacity-100" : "scale-75 opacity-0"
            }`}
          >
            <Card className="shadow-2xl border-accent/30 bg-card">
              <CardContent className="p-8">
                <div className="flex justify-between items-start mb-6">
                  <h3 className="text-4xl font-bold text-primary">
                    {getEventField(events.find((e) => e.sys.id === expandedEvent) || events[0], "title", "Etkinlik")}
                  </h3>
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      toggleEvent(expandedEvent)
                    }}
                    className="text-muted-foreground hover:text-accent text-3xl transition-all duration-300 hover:scale-110 hover:rotate-90 p-2"
                  >
                    ×
                  </button>
                </div>
                <div className="grid md:grid-cols-2 gap-8">
                  {(() => {
                    const event = events.find((e) => e.sys.id === expandedEvent)
                    if (!event) return null

                    const imageUrl = getEventImage(event)
                    const title = getEventField(event, "title", "Etkinlik")
                    const fullDescription = getEventField(event, "fullDescription", "Detaylı açıklama mevcut değil")

                    return (
                      <>
                        <img
                          src={imageUrl || "/placeholder.svg"}
                          alt={title}
                          className="w-full h-80 object-cover rounded-lg shadow-lg border-2 border-accent/20"
                        />
                        <div className="flex flex-col justify-center">
                          <p className="text-foreground leading-relaxed text-xl">{fullDescription}</p>
                        </div>
                      </>
                    )
                  })()}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </>
  )
}
