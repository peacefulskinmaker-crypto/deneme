"use client"
import { Navigation } from "@/components/navigation"
import { PhotoCarousel } from "@/components/photo-carousel"
import { AboutSection } from "@/components/about-section"
import { EventsSection } from "@/components/events-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <PhotoCarousel />
      <AboutSection />
      <EventsSection />
      <Footer />
    </main>
  )
}
